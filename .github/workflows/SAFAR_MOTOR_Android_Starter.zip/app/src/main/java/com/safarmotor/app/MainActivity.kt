package com.safarmotor.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B0A0F)
private val Panel = Color(0xFF1B1A24)
private val Orange = Color(0xFFFF713D)
private val Muted = Color(0xFF9B99A8)
private val Green = Color(0xFF13C6A0)
private val Blue = Color(0xFF173B67)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SafarApp() }
    }
}

@Composable
fun SafarApp() {
    var selected by remember { mutableStateOf(0) }
    var showNewTransaction by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Orange, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF14131B), contentColor = Muted) {
                    val items = listOf("Dashboard", "Pelanggan", "Transaksi", "Sparepart", "Laporan")
                    val icons = listOf(Icons.Default.Dashboard, Icons.Default.People, Icons.Default.ReceiptLong, Icons.Default.Inventory2, Icons.Default.BarChart)
                    items.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = selected == index,
                            onClick = { selected = index },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Orange, selectedTextColor = Orange, indicatorColor = Panel, unselectedIconColor = Muted, unselectedTextColor = Muted)
                        )
                    }
                }
            },
            floatingActionButton = {
                if (selected in 1..3) {
                    FloatingActionButton(onClick = { if (selected == 2) showNewTransaction = true }, containerColor = Orange, contentColor = Color.White) {
                        Icon(Icons.Default.Add, contentDescription = "Tambah")
                    }
                }
            }
        ) { padding ->
            when (selected) {
                0 -> Dashboard(Modifier.padding(padding), onNew = { selected = 2; showNewTransaction = true })
                1 -> Customers(Modifier.padding(padding))
                2 -> Transactions(Modifier.padding(padding), onNew = { showNewTransaction = true })
                3 -> Spareparts(Modifier.padding(padding))
                else -> Reports(Modifier.padding(padding))
            }
        }
        if (showNewTransaction) NewTransactionDialog(onDismiss = { showNewTransaction = false })
    }
}

@Composable
fun Page(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    LazyColumn(modifier.fillMaxSize().background(Bg).padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 22.dp, bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Column(verticalArrangement = Arrangement.spacedBy(14.dp), content = content) }
    }
}
@Composable
fun Dashboard(modifier: Modifier, onNew: () -> Unit) {
    Page(modifier) {
        Text("Selamat datang", color = Muted, fontSize = 14.sp)
        Text("SAFAR MOTOR", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
        Card(colors = CardDefaults.cardColors(containerColor = Blue), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("PENDAPATAN KOTOR", color = Color(0xFFB7C7D9), fontWeight = FontWeight.SemiBold)
                Text("Rp 0", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                Text("Ringkasan periode berjalan", color = Color(0xFF9AB6D4), fontSize = 12.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MiniMetric("Tahun ini", "Rp 0")
                    MiniMetric("Bulan ini", "Rp 0")
                    MiniMetric("Belum lunas", "Rp 0")
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("TOTAL SPAREPART", "0", Icons.Default.Inventory2, Green, Modifier.weight(1f))
            MetricCard("TOTAL JASA", "0", Icons.Default.Build, Orange, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("STOK MENIPIS", "0", Icons.Default.Warning, Color(0xFFFFC02E), Modifier.weight(1f))
            MetricCard("STOK HABIS", "0", Icons.Default.Error, Color(0xFFFF526B), Modifier.weight(1f))
        }
        Text("Ringkasan Antrean", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Row(Modifier.fillMaxWidth().padding(vertical = 20.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                MiniMetric("Antrean", "0"); MiniMetric("Dikerjakan", "0"); MiniMetric("Menunggu bayar", "0")
            }
        }
        Text("Aksi Cepat", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickAction("Transaksi baru", Icons.Default.AddCircle, onNew, Modifier.weight(1f))
            QuickAction("Pelanggan", Icons.Default.PersonAdd, {}, Modifier.weight(1f))
            QuickAction("Daftar jasa", Icons.Default.Handyman, {}, Modifier.weight(1f))
        }
        Text("Catatan: data pada versi awal ini masih contoh/demo.", color = Muted, fontSize = 12.sp)
    }
}
@Composable
fun MiniMetric(label: String, value: String) {
    Column(Modifier.padding(3.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(label, color = Muted, fontSize = 11.sp)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}
@Composable
fun MetricCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF393744))) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(42.dp).background(tint.copy(alpha = .15f), RoundedCornerShape(50)), contentAlignment = Alignment.Center) { Icon(icon, null, tint) }
            Text(title, color = Muted, fontSize = 11.sp)
            Text(value, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        }
    }
}
@Composable
fun QuickAction(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, action: () -> Unit, modifier: Modifier = Modifier) {
    Card(modifier.clickable { action() }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 18.dp, horizontal = 5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, Orange, modifier = Modifier.size(28.dp))
            Text(title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
@Composable
fun SectionPage(modifier: Modifier, title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: String) {
    Page(modifier) {
        Text(title, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
        Text(subtitle, color = Muted)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(icon, null, Orange, modifier = Modifier.size(42.dp))
                Text(content, color = Muted)
            }
        }
    }
}
@Composable
fun Customers(modifier: Modifier) = SectionPage(modifier, "Pelanggan", "Data pelanggan dan kendaraan", Icons.Default.People, "Belum ada pelanggan. Tambahkan fitur form pelanggan pada tahap berikutnya.")
@Composable
fun Transactions(modifier: Modifier, onNew: () -> Unit) {
    Page(modifier) {
        Text("Transaksi", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
        Text("Riwayat servis dan pembayaran", color = Muted)
        Button(onClick = onNew, colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Transaksi Baru") }
        EmptyPanel("Belum ada transaksi")
    }
}
@Composable
fun Spareparts(modifier: Modifier) = SectionPage(modifier, "Sparepart", "Stok, harga, dan supplier", Icons.Default.Inventory2, "Belum ada sparepart. Data stok akan ditambahkan pada tahap berikutnya.")
@Composable
fun Reports(modifier: Modifier) = SectionPage(modifier, "Laporan", "Statistik dan analitik bengkel", Icons.Default.BarChart, "Laporan akan muncul setelah transaksi tercatat.")
@Composable
fun EmptyPanel(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Box(Modifier.fillMaxWidth().padding(35.dp), contentAlignment = Alignment.Center) { Text(message, color = Muted) }
    }
}
@Composable
fun NewTransactionDialog(onDismiss: () -> Unit) {
    var customer by remember { mutableStateOf("") }
    var plate by remember { mutableStateOf("") }
    var service by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Transaksi Baru") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(customer, { customer = it }, label = { Text("Nama pelanggan") }, singleLine = true)
                OutlinedTextField(plate, { plate = it }, label = { Text("Nomor polisi") }, singleLine = true)
                OutlinedTextField(service, { service = it }, label = { Text("Jasa / keluhan") }, singleLine = true)
                OutlinedTextField(amount, { amount = it }, label = { Text("Total (Rp)") }, singleLine = true)
                Text("Form demo: transaksi belum disimpan ke database.", color = Muted, fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Selesai", color = Orange) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

# SAFAR MOTOR — Android starter project

Starter project Android native (Kotlin + Jetpack Compose) for a workshop management app inspired by your screenshots.

## Included in this starter
- Dark theme with orange accent
- Bottom navigation: Dashboard, Pelanggan, Transaksi, Sparepart, Laporan
- Dashboard summary cards and quick actions
- Demo data so the interface is visible immediately
- Initial screen scaffolds for customer, transaction, stock, and report sections

## Important: online/cloud setup
This is source code, not a compiled APK. To enable real multi-device online data:
1. Open the project in Android Studio.
2. Create a Firebase project at https://console.firebase.google.com/
3. Add an Android app with package name `com.safarmotor.app`.
4. Download `google-services.json` and place it in the `app/` directory.
5. Enable **Authentication** (Email/Password) and **Cloud Firestore** in Firebase.
6. Add the Google Services Gradle plugin and Firebase dependencies following the current Firebase Android setup guide.
7. Implement/verify Firebase Authentication and Firestore security rules before using real customer data.

Cloud sync, authentication, printing, scheduled reminders, payroll calculations, and Excel export are planned integration points, not yet production-ready in this starter. Don't enter real customer information until authentication and Firestore security rules are configured.

## Build
Open the folder in Android Studio, let Gradle sync, then run on an Android device or emulator. A compatible Android SDK and internet connection are needed. The Gradle wrapper files are not bundled; Android Studio can generate/configure them when importing the project.

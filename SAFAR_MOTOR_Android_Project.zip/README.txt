SAFAR MOTOR — Proyek Android awal yang dapat dibuka di Android Studio

YANG SUDAH ADA
- Aplikasi Android berbasis WebView dengan logo SAFAR MOTOR lengkap.
- Tema gelap dengan aksen oranye.
- Navigasi Dashboard, Pelanggan, Transaksi, Sparepart, Laporan.
- Tambah/hapus data pelanggan, transaksi, dan sparepart.
- Ringkasan pendapatan dari transaksi yang tersimpan.
- Cetak nota melalui dialog cetak WebView (dukungan tergantung perangkat).
- Ekspor laporan CSV yang bisa dibuka di Excel.
- Backup dan pemulihan JSON.
- Pencarian data.

PENTING
Ini adalah MVP lokal yang bisa dijalankan sebagai proyek Android, bukan APK yang sudah dikompilasi.
Data tersimpan di perangkat melalui localStorage. Mode online/sinkronisasi cloud, notifikasi pengingat servis terjadwal, gaji mekanik, dan autentikasi belum aktif karena memerlukan backend serta konfigurasi akun/server. Jangan gunakan data pelanggan sungguhan sebelum menambahkan keamanan, backup teruji, dan sinkronisasi.

CARA MEMBUKA
1. Instal Android Studio di komputer/laptop.
2. Ekstrak ZIP.
3. Android Studio > Open > pilih folder SAFAR_MOTOR_Android_Project.
4. Tunggu Gradle Sync selesai (perlu internet pertama kali).
5. Hubungkan HP dengan USB debugging atau pilih emulator.
6. Klik Run ▶.

Package ID: id.safarmotor.app
Min Android: Android 6.0 (API 23)
Target SDK: 35

Untuk menjadi aplikasi online multi-perangkat, langkah berikutnya adalah menyiapkan Firebase (Authentication + Firestore) atau backend sendiri. Kredensial backend jangan dibagikan secara publik.
